package com.example.raj_liangjian;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.raj_liangjian.Mapper.DishMapper;
import com.example.raj_liangjian.entity.Employee;
import com.example.raj_liangjian.service.EmployeeService;
import com.sun.org.apache.bcel.internal.generic.NEW;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.List;

@SpringBootTest
class ApplicationTests {

    @Test
    void contextLoads() {

    }


}
