package com.example.raj_liangjian.common;

public class CustomException extends RuntimeException{

    public CustomException(String message){
        super(message);
    }

}
