package com.example.raj_liangjian.service.impl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.raj_liangjian.Mapper.SetmealDishMapper;
import com.example.raj_liangjian.entity.SetmealDish;
import com.example.raj_liangjian.service.SetmealDishService;
import org.springframework.stereotype.Service;

@Service
public class SetmealDishServiceImpl extends ServiceImpl<SetmealDishMapper, SetmealDish> implements SetmealDishService {
}
