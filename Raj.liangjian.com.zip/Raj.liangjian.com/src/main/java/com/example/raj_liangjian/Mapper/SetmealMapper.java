package com.example.raj_liangjian.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.raj_liangjian.entity.Setmeal;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SetmealMapper extends BaseMapper<Setmeal> {
}
