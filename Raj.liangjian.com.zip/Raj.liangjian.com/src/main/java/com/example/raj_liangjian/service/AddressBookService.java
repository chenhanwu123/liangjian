package com.example.raj_liangjian.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.raj_liangjian.entity.AddressBook;

public interface AddressBookService extends IService<AddressBook> {
}
